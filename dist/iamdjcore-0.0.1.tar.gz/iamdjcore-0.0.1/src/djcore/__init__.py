def add(a):
    return a+3