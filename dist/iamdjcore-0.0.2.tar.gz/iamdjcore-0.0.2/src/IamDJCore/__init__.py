def add(a):
    return a+8