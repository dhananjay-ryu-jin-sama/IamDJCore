Hare Krishna

#djcore 
Only package you will every need ;).