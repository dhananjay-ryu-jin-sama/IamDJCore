def add(a):
    return a+1