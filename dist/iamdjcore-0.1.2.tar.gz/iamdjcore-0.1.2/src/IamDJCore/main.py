print("HARE KRISHNA")

def add(a):
    return a + 1