Hare Krishna

#djcore 
Only package you will every need ;).

Version = 0.0.1 - test 1
Version = 0.0.2 - test 2
Version = 0.1.0 - Search Dijkstra
Version = 0.1.1 - Search BFS DFS Astar Greedy Dijikstra