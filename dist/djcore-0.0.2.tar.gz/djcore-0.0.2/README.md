Hare Krishna

#djcore 
Only package you willevery need ;).